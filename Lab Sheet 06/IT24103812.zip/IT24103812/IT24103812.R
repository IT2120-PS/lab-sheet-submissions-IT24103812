setwd("C:/Users/User/Desktop/IT24103812")
#part 1
#i
#Binomial Distribution
#ii
1- pbinom(47,50,0.85,lower.tail =TRUE)-pbinom(47,50,0.85,lower.tail =FALSE)
#part 2
#i X = the number of customer calls received in an hour.
#ii. poisson distribution
#iii
dpois(15,12)
