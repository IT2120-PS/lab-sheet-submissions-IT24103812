setwd("C:/Users/User/Desktop/IT24103812")
getwd()
sample <- rnorm(25, mean =45, sd =2)

t.test (sample, mu=46, alternative = "less")
